package com.example.demo.controller;

public record AuthDTO(String username, String password) {

}
